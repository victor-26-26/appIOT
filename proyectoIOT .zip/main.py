import network
import time
import ntptime
from machine import Pin
import urequests

ssid = "Wokwi-GUEST"
password = ""

print("Conectando a Wi-Fi...", end="")
sta_if = network.WLAN(network.STA_IF)
sta_if.active(True)
sta_if.connect(ssid, password)

intentos = 0
while not sta_if.isconnected() and intentos < 30:
    print(".", end="")
    time.sleep(0.5)
    intentos += 1

if sta_if.isconnected():
    print("\n¡Conectado a la red Wi-Fi!")
    
    # Sincronizar la hora real con un servidor NTP al iniciar
    print("Sincronizando hora con servidor NTP...")
    try:
        ntptime.settime()
        print("¡Hora sincronizada correctamente!")
    except Exception as e:
        print("No se pudo sincronizar la hora NTP:", e)
else:
    print("\nError al conectar Wi-Fi.")

pir = Pin(15, Pin.IN)
FIREBASE_URL = "https://appiot-d8d3f-default-rtdb.firebaseio.com/eventos.json"

print("Iniciando monitoreo de movimiento...")
ultimo_estado = 0

while True:
    estado_actual = pir.value()

    if estado_actual == 1 and ultimo_estado == 0:
        print("¡Movimiento detectado!")
        ultimo_estado = 1
        # en wokwi no puede conectarse a red wifi externa, por eso la fecha es de muy atras
        # en el prototipo fisico este codigo en teoria no deberia dar el error de las fechas.
        # Generar timestamp en milisegundos
        # Si estás en otra zona horaria, puedes cambiar este valor (ej. -4 horas = -14400)
        desfase_horario_segundos = -3 * 3600
        timestamp_actual = time.time() + desfase_horario_segundos
        timestamp_ms = int(timestamp_actual * 1000)
        
        datos = {
            "estado": "Movimiento Detectado",
            "timestamp": timestamp_ms
        }

        try:
            response = urequests.post(FIREBASE_URL, json=datos)
            print("Dato enviado a Firebase. Código:", response.status_code)
            response.close()
        except Exception as e:
            print("Error al enviar datos a Firebase:", e)

    elif estado_actual == 0 and ultimo_estado == 1:
        print("Sensor normal (sin movimiento).")
        ultimo_estado = 0

    time.sleep(1)